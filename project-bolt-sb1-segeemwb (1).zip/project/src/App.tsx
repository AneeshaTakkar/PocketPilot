import React, { useState } from 'react';
import { 
  FileText, 
  TrendingUp, 
  Users, 
  PieChart, 
  Upload, 
  AlertCircle,
  IndianRupee,
  Target,
  Eye,
  Shield
} from 'lucide-react';
import AuthPage from './components/AuthPage';
import Dashboard from './components/Dashboard';
import UploadPage from './components/UploadPage';
import AnalysisPage from './components/AnalysisPage';
import PeerComparison from './components/PeerComparison';
import Navigation from './components/Navigation';

function App() {
  const [currentView, setCurrentView] = useState<'auth' | 'upload' | 'dashboard' | 'analysis' | 'peer'>('auth');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [analysisData, setAnalysisData] = useState(null);

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentView('upload');
  };

  const handleAnalysisComplete = (data: any) => {
    setAnalysisData(data);
    setCurrentView('dashboard');
  };

  if (!isAuthenticated) {
    return <AuthPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="container mx-auto px-4 py-8">
        {currentView === 'upload' && (
          <UploadPage onAnalysisComplete={handleAnalysisComplete} />
        )}
        
        {currentView === 'dashboard' && analysisData && (
          <Dashboard data={analysisData} />
        )}
        
        {currentView === 'analysis' && analysisData && (
          <AnalysisPage data={analysisData} />
        )}
        
        {currentView === 'peer' && analysisData && (
          <PeerComparison data={analysisData} />
        )}
      </main>
    </div>
  );
}

export default App;