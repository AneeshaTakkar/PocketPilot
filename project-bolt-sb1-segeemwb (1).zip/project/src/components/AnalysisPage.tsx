import React from 'react';
import { BarChart, LineChart, TrendingUp, Calendar, Filter } from 'lucide-react';

interface AnalysisPageProps {
  data: any;
}

const AnalysisPage: React.FC<AnalysisPageProps> = ({ data }) => {
  const { totalSpending, categories, monthlyTrend } = data;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  // Calculate daily average
  const dailyAverage = Math.round(totalSpending / 31);
  
  // Weekly spending pattern (mock data)
  const weeklyPattern = [
    { day: 'Mon', spending: 1200 },
    { day: 'Tue', spending: 980 },
    { day: 'Wed', spending: 1450 },
    { day: 'Thu', spending: 1100 },
    { day: 'Fri', spending: 2100 },
    { day: 'Sat', spending: 2800 },
    { day: 'Sun', spending: 1600 }
  ];

  const topExpenses = [
    { date: '2024-01-15', description: 'Amazon Shopping - Electronics', amount: 15000, category: 'Shopping' },
    { date: '2024-01-22', description: 'Fine Dining at Taj Hotel', amount: 4500, category: 'Food & Dining' },
    { date: '2024-01-10', description: 'Uber Rides Premium', amount: 3200, category: 'Transportation' },
    { date: '2024-01-28', description: 'Medical Consultation & Tests', amount: 2800, category: 'Healthcare' },
    { date: '2024-01-05', description: 'Electricity Bill Payment', amount: 2400, category: 'Utilities & Bills' }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Detailed Analysis</h1>
        <p className="text-gray-600">Deep dive into your spending patterns and behaviors</p>
      </div>

      {/* Analysis Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="text-center">
            <div className="bg-blue-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">{formatCurrency(dailyAverage)}</p>
            <p className="text-sm text-gray-600">Daily Average</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="text-center">
            <div className="bg-green-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">18</p>
            <p className="text-sm text-gray-600">Active Days</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="text-center">
            <div className="bg-purple-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
              <BarChart className="h-6 w-6 text-purple-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">₹8.2K</p>
            <p className="text-sm text-gray-600">Avg Transaction</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="text-center">
            <div className="bg-orange-100 p-3 rounded-full w-12 h-12 mx-auto mb-3 flex items-center justify-center">
              <Filter className="h-6 w-6 text-orange-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">6</p>
            <p className="text-sm text-gray-600">Categories</p>
          </div>
        </div>
      </div>

      {/* Weekly Spending Pattern */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Weekly Spending Pattern</h2>
        <div className="flex items-end space-x-4 h-48">
          {weeklyPattern.map((day) => (
            <div key={day.day} className="flex-1 flex flex-col items-center">
              <div
                className="w-full bg-gradient-to-t from-teal-500 to-teal-400 rounded-t-lg mb-2 transition-all hover:from-teal-600 hover:to-teal-500"
                style={{
                  height: `${(day.spending / Math.max(...weeklyPattern.map(d => d.spending))) * 150}px`,
                  minHeight: '20px'
                }}
              ></div>
              <p className="text-sm font-medium text-gray-700">{day.day}</p>
              <p className="text-xs text-gray-500">₹{day.spending.toLocaleString()}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 p-4 bg-teal-50 rounded-lg">
          <p className="text-sm text-teal-800">
            <strong>Insight:</strong> You tend to spend more on weekends, especially Saturdays. Consider planning weekend activities with a budget.
          </p>
        </div>
      </div>

      {/* Top Expenses */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Top 5 Expenses This Month</h2>
        <div className="space-y-4">
          {topExpenses.map((expense, index) => (
            <div key={index} className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="bg-blue-100 p-2 rounded-lg mr-4">
                <span className="text-blue-600 font-bold text-sm">#{index + 1}</span>
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{expense.description}</p>
                <div className="flex items-center text-sm text-gray-600 space-x-4">
                  <span>{expense.date}</span>
                  <span>•</span>
                  <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">
                    {expense.category}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-gray-900">{formatCurrency(expense.amount)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Spending Velocity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Spending Velocity</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Week 1</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 h-2 bg-gray-200 rounded-full">
                  <div className="w-16 h-2 bg-blue-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-700">₹11,200</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Week 2</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 h-2 bg-gray-200 rounded-full">
                  <div className="w-20 h-2 bg-green-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-700">₹9,800</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Week 3</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 h-2 bg-gray-200 rounded-full">
                  <div className="w-24 h-2 bg-red-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-700">₹15,250</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Week 4</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 h-2 bg-gray-200 rounded-full">
                  <div className="w-18 h-2 bg-blue-500 rounded-full"></div>
                </div>
                <span className="text-sm text-gray-700">₹9,000</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Category Trends</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Food & Dining</span>
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 text-red-500 mr-1" />
                <span className="text-red-500 text-sm">+15%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Transportation</span>
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1 transform rotate-180" />
                <span className="text-green-500 text-sm">-8%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Shopping</span>
              <div className="flex items-center">
                <TrendingUp className="h-4 w-4 text-red-500 mr-1" />
                <span className="text-red-500 text-sm">+32%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-700">Utilities</span>
              <div className="flex items-center">
                <div className="w-4 h-4 mr-1"></div>
                <span className="text-gray-500 text-sm">±0%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisPage;