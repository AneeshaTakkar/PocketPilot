import React from 'react';
import { IndianRupee, TrendingUp, TrendingDown, AlertCircle, Lightbulb, PieChart } from 'lucide-react';

interface DashboardProps {
  data: any;
}

const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const { totalSpending, categories, unusualExpenses, savingTips, monthlyTrend } = data;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getCategoryPercentage = (amount: number) => {
    return ((amount / totalSpending) * 100).toFixed(1);
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'Food & Dining': 'bg-orange-500',
      'Transportation': 'bg-blue-500',
      'Utilities & Bills': 'bg-green-500',
      'Shopping': 'bg-purple-500',
      'Healthcare': 'bg-red-500',
      'Entertainment': 'bg-pink-500',
    };
    return colors[category] || 'bg-gray-500';
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Financial Dashboard</h1>
        <p className="text-gray-600">Your spending insights for January 2024</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 p-3 rounded-lg">
              <IndianRupee className="h-6 w-6 text-blue-600" />
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalSpending)}</p>
              <p className="text-sm text-gray-600">Total Spending</p>
            </div>
          </div>
          <div className="flex items-center text-red-600">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span className="text-sm">+8.5% from last month</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-red-100 p-3 rounded-lg">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{unusualExpenses.length}</p>
              <p className="text-sm text-gray-600">Unusual Expenses</p>
            </div>
          </div>
          <div className="flex items-center text-red-600">
            <span className="text-sm">Worth ₹{unusualExpenses.reduce((sum: number, exp: any) => sum + exp.amount, 0).toLocaleString()}</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 p-3 rounded-lg">
              <Lightbulb className="h-6 w-6 text-green-600" />
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">₹4,200</p>
              <p className="text-sm text-gray-600">Potential Savings</p>
            </div>
          </div>
          <div className="flex items-center text-green-600">
            <TrendingDown className="h-4 w-4 mr-1" />
            <span className="text-sm">Based on AI recommendations</span>
          </div>
        </div>
      </div>

      {/* Spending Categories */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center mb-6">
          <PieChart className="h-6 w-6 text-blue-600 mr-3" />
          <h2 className="text-xl font-bold text-gray-900">Spending by Category</h2>
        </div>
        
        <div className="space-y-4">
          {Object.entries(categories).map(([category, amount]) => (
            <div key={category} className="flex items-center">
              <div className="flex-1">
                <div className="flex justify-between mb-2">
                  <span className="font-medium text-gray-900">{category}</span>
                  <span className="text-gray-600">{formatCurrency(amount as number)}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${getCategoryColor(category)}`}
                    style={{ width: `${getCategoryPercentage(amount as number)}%` }}
                  ></div>
                </div>
              </div>
              <span className="ml-4 text-sm text-gray-500 min-w-[3rem] text-right">
                {getCategoryPercentage(amount as number)}%
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Monthly Trend */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Monthly Spending Trend</h2>
        <div className="flex items-end space-x-4 h-64">
          {monthlyTrend.map((month: any, index: number) => (
            <div key={month.month} className="flex-1 flex flex-col items-center">
              <div
                className="w-full bg-blue-500 rounded-t-lg mb-2 transition-all hover:bg-blue-600"
                style={{
                  height: `${(month.spending / Math.max(...monthlyTrend.map((m: any) => m.spending))) * 200}px`,
                  minHeight: '20px'
                }}
              ></div>
              <p className="text-sm font-medium text-gray-700">{month.month}</p>
              <p className="text-xs text-gray-500">₹{(month.spending / 1000).toFixed(0)}K</p>
            </div>
          ))}
        </div>
      </div>

      {/* AI-Powered Saving Tips */}
      <div className="bg-gradient-to-r from-green-50 to-teal-50 rounded-xl p-6 border border-green-200">
        <div className="flex items-center mb-6">
          <Lightbulb className="h-6 w-6 text-green-600 mr-3" />
          <h2 className="text-xl font-bold text-green-800">Personalized Saving Tips</h2>
        </div>
        
        <div className="space-y-4">
          {savingTips.map((tip: string, index: number) => (
            <div key={index} className="bg-white p-4 rounded-lg border border-green-200">
              <div className="flex items-start">
                <div className="bg-green-100 p-2 rounded-full mr-3 mt-1">
                  <span className="text-green-600 font-semibold text-sm">{index + 1}</span>
                </div>
                <p className="text-gray-700 leading-relaxed">{tip}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Unusual Expenses Alert */}
      {unusualExpenses.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <AlertCircle className="h-6 w-6 text-red-600 mr-3" />
            <h2 className="text-xl font-bold text-red-800">Unusual Expenses Detected</h2>
          </div>
          
          <div className="space-y-3">
            {unusualExpenses.map((expense: any, index: number) => (
              <div key={index} className="bg-white p-4 rounded-lg border border-red-200">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-medium text-gray-900">{expense.description}</p>
                    <p className="text-sm text-gray-600">{expense.date} • {expense.category}</p>
                  </div>
                  <span className="text-lg font-bold text-red-600">{formatCurrency(expense.amount)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;