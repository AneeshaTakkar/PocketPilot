import React, { useState, useCallback } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, Loader2, TrendingUp } from 'lucide-react';

interface UploadPageProps {
  onAnalysisComplete: (data: any) => void;
}

const UploadPage: React.FC<UploadPageProps> = ({ onAnalysisComplete }) => {
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type === 'text/csv') {
        setFile(droppedFile);
        setUploadStatus('success');
      } else {
        setUploadStatus('error');
      }
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.type === 'text/csv') {
        setFile(selectedFile);
        setUploadStatus('success');
      } else {
        setUploadStatus('error');
      }
    }
  };

  const handleAnalyze = () => {
    if (!file) return;
    
    setIsAnalyzing(true);
    
    // Simulate analysis with demo data
    setTimeout(() => {
      const mockData = {
        totalSpending: 45250,
        categories: {
          'Food & Dining': 12500,
          'Transportation': 8750,
          'Utilities & Bills': 9800,
          'Shopping': 7200,
          'Healthcare': 3500,
          'Entertainment': 3500
        },
        unusualExpenses: [
          { description: 'Online Shopping - Electronics', amount: 15000, category: 'Shopping', date: '2024-01-15' },
          { description: 'Restaurant Bill - Fine Dining', amount: 4500, category: 'Food & Dining', date: '2024-01-22' }
        ],
        savingTips: [
          'Consider cooking at home more often. You could save ₹3,000 monthly by reducing restaurant visits.',
          'Review your subscription services. You have multiple streaming services costing ₹1,200 monthly.',
          'Use public transport or carpooling. Your transport expenses are 20% higher than similar profiles.'
        ],
        monthlyTrend: [
          { month: 'Oct', spending: 42000 },
          { month: 'Nov', spending: 38000 },
          { month: 'Dec', spending: 45250 },
          { month: 'Jan', spending: 41000 }
        ]
      };
      
      setIsAnalyzing(false);
      onAnalysisComplete(mockData);
    }, 3000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Upload Your Transaction Data</h1>
        <p className="text-gray-600 text-lg">
          Upload your bank statement CSV to get personalized financial insights
        </p>
      </div>

      {/* File Upload Area */}
      <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
        <div
          className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
            dragActive
              ? 'border-blue-500 bg-blue-50'
              : file
              ? 'border-green-500 bg-green-50'
              : uploadStatus === 'error'
              ? 'border-red-500 bg-red-50'
              : 'border-gray-300 bg-gray-50 hover:border-blue-400'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          {file ? (
            <div className="space-y-4">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
              <h3 className="text-xl font-semibold text-green-700">File Ready</h3>
              <p className="text-green-600">{file.name}</p>
              <p className="text-sm text-gray-500">File size: {(file.size / 1024).toFixed(1)} KB</p>
            </div>
          ) : uploadStatus === 'error' ? (
            <div className="space-y-4">
              <AlertCircle className="h-16 w-16 text-red-500 mx-auto" />
              <h3 className="text-xl font-semibold text-red-700">Invalid File Type</h3>
              <p className="text-red-600">Please upload a CSV file only</p>
            </div>
          ) : (
            <div className="space-y-4">
              <Upload className="h-16 w-16 text-gray-400 mx-auto" />
              <h3 className="text-xl font-semibold text-gray-700">Drop your CSV file here</h3>
              <p className="text-gray-500">or click to browse</p>
            </div>
          )}
          
          <input
            type="file"
            accept=".csv"
            onChange={handleFileChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
        </div>
      </div>

      {/* CSV Format Guide */}
      <div className="bg-blue-50 rounded-xl p-6 mb-8">
        <h3 className="font-semibold text-blue-900 mb-4 flex items-center">
          <FileText className="h-5 w-5 mr-2" />
          Expected CSV Format
        </h3>
        <div className="bg-white p-4 rounded-lg font-mono text-sm">
          <div className="text-gray-600 mb-2">Headers should include:</div>
          <div className="text-blue-600">Date, Description, Amount, Category (optional)</div>
          <div className="text-gray-500 text-xs mt-2">
            Example: 2024-01-15, Swiggy Food Order, -450, Food
          </div>
        </div>
      </div>

      {/* Analyze Button */}
      {file && (
        <div className="text-center">
          <button
            onClick={handleAnalyze}
            disabled={isAnalyzing}
            className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center mx-auto space-x-2"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                <span>Analyzing your data...</span>
              </>
            ) : (
              <>
                <TrendingUp className="h-5 w-5" />
                <span>Analyze My Spending</span>
              </>
            )}
          </button>
          
          {isAnalyzing && (
            <div className="mt-6 bg-white rounded-lg p-6">
              <div className="space-y-3">
                <div className="flex items-center text-blue-600">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mr-3"></div>
                  Categorizing transactions...
                </div>
                <div className="flex items-center text-gray-400">
                  <div className="w-2 h-2 bg-gray-300 rounded-full mr-3"></div>
                  Detecting unusual expenses...
                </div>
                <div className="flex items-center text-gray-400">
                  <div className="w-2 h-2 bg-gray-300 rounded-full mr-3"></div>
                  Generating saving tips...
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default UploadPage;