import React from 'react';
import { Users, TrendingUp, TrendingDown, Target, Award, AlertTriangle } from 'lucide-react';

interface PeerComparisonProps {
  data: any;
}

const PeerComparison: React.FC<PeerComparisonProps> = ({ data }) => {
  const { totalSpending, categories } = data;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  // Mock peer data for Indian context
  const peerProfile = {
    age: '25-35',
    city: 'Delhi NCR',
    income: '₹8-12 LPA',
    lifestyle: 'Young Professional'
  };

  const peerAverages = {
    total: 38500,
    categories: {
      'Food & Dining': 9800,
      'Transportation': 7500,
      'Utilities & Bills': 8500,
      'Shopping': 5200,
      'Healthcare': 2800,
      'Entertainment': 4700
    }
  };

  const getComparisonStatus = (your: number, peer: number) => {
    const diff = ((your - peer) / peer) * 100;
    if (Math.abs(diff) <= 10) return { status: 'similar', color: 'text-gray-600', icon: '±' };
    return diff > 0 
      ? { status: 'higher', color: 'text-red-600', icon: '+', diff: diff.toFixed(0) }
      : { status: 'lower', color: 'text-green-600', icon: '', diff: Math.abs(diff).toFixed(0) };
  };

  const insights = [
    {
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      title: 'Food Spending Alert',
      message: 'Your food spending is 27% higher than peers in Delhi NCR. Consider meal planning to save ₹2,700/month.',
    },
    {
      icon: Award,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      title: 'Healthcare Savings',
      message: 'Great job! Your healthcare spending is 25% lower than average while maintaining good coverage.',
    },
    {
      icon: Target,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      title: 'Transportation Efficiency',
      message: 'Your transport costs are 17% higher. Try carpooling or metro passes to match peer averages.',
    },
  ];

  const spendingRank = {
    overall: 68,
    categories: {
      'Food & Dining': 78,
      'Transportation': 72,
      'Utilities & Bills': 55,
      'Shopping': 83,
      'Healthcare': 42,
      'Entertainment': 65
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Peer Comparison</h1>
        <p className="text-gray-600">See how your spending compares with similar profiles across India</p>
      </div>

      {/* Profile Match */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
        <div className="flex items-center mb-4">
          <Users className="h-6 w-6 text-blue-600 mr-3" />
          <h2 className="text-xl font-bold text-blue-900">Your Peer Group</h2>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-700">{peerProfile.age}</p>
            <p className="text-sm text-blue-600">Age Group</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-700">{peerProfile.city}</p>
            <p className="text-sm text-blue-600">Location</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-700">{peerProfile.income}</p>
            <p className="text-sm text-blue-600">Income Range</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-700">2.8K+</p>
            <p className="text-sm text-blue-600">Similar Users</p>
          </div>
        </div>
      </div>

      {/* Overall Comparison */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Overall Spending Comparison</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">Your Spending</p>
            <p className="text-3xl font-bold text-gray-900">{formatCurrency(totalSpending)}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-2">Peer Average</p>
            <p className="text-3xl font-bold text-gray-600">{formatCurrency(peerAverages.total)}</p>
          </div>
        </div>

        <div className="bg-red-50 p-4 rounded-lg text-center">
          <div className="flex items-center justify-center mb-2">
            <TrendingUp className="h-5 w-5 text-red-600 mr-2" />
            <span className="text-red-600 font-semibold">
              You spend {getComparisonStatus(totalSpending, peerAverages.total).diff}% more than peers
            </span>
          </div>
          <p className="text-sm text-red-700">That's ₹{(totalSpending - peerAverages.total).toLocaleString()} extra per month</p>
        </div>
      </div>

      {/* Category Comparison */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Category-wise Comparison</h2>
        
        <div className="space-y-6">
          {Object.entries(categories).map(([category, amount]) => {
            const peerAmount = peerAverages.categories[category as keyof typeof peerAverages.categories];
            const comparison = getComparisonStatus(amount as number, peerAmount);
            const rank = spendingRank.categories[category as keyof typeof spendingRank.categories];
            
            return (
              <div key={category} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-semibold text-gray-900">{category}</h3>
                  <div className="text-right">
                    <div className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">
                      Rank: {rank}/100
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">You</p>
                    <p className="font-bold text-gray-900">{formatCurrency(amount as number)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Peer Avg</p>
                    <p className="font-bold text-gray-600">{formatCurrency(peerAmount)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Difference</p>
                    <p className={`font-bold ${comparison.color}`}>
                      {comparison.status === 'similar' ? 'Similar' : 
                       `${comparison.icon}${comparison.diff}%`}
                    </p>
                  </div>
                </div>
                
                {/* Progress bars */}
                <div className="space-y-2">
                  <div className="flex items-center">
                    <span className="text-xs text-gray-500 w-12">You</span>
                    <div className="flex-1 bg-gray-200 rounded-full h-2 ml-2">
                      <div 
                        className="bg-blue-500 h-2 rounded-full"
                        style={{ width: `${Math.min((amount as number / Math.max(amount as number, peerAmount)) * 100, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className="text-xs text-gray-500 w-12">Peer</span>
                    <div className="flex-1 bg-gray-200 rounded-full h-2 ml-2">
                      <div 
                        className="bg-gray-400 h-2 rounded-full"
                        style={{ width: `${Math.min((peerAmount / Math.max(amount as number, peerAmount)) * 100, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Insights & Recommendations */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Peer Insights & Recommendations</h2>
        
        <div className="space-y-4">
          {insights.map((insight, index) => {
            const IconComponent = insight.icon;
            return (
              <div key={index} className={`p-4 rounded-lg ${insight.bgColor}`}>
                <div className="flex items-start">
                  <div className={`p-2 rounded-full mr-4 ${insight.bgColor}`}>
                    <IconComponent className={`h-5 w-5 ${insight.color}`} />
                  </div>
                  <div>
                    <h3 className={`font-semibold ${insight.color} mb-1`}>{insight.title}</h3>
                    <p className="text-gray-700">{insight.message}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Savings Leaderboard */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200">
        <h2 className="text-xl font-bold text-green-800 mb-6">How You Can Improve</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg text-center">
            <Target className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <p className="font-semibold text-gray-900">Target Rank</p>
            <p className="text-2xl font-bold text-green-600">Top 50</p>
            <p className="text-xs text-gray-600">Currently at 68/100</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg text-center">
            <TrendingDown className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <p className="font-semibold text-gray-900">Potential Savings</p>
            <p className="text-2xl font-bold text-blue-600">₹6,750</p>
            <p className="text-xs text-gray-600">Per month</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg text-center">
            <Award className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <p className="font-semibold text-gray-900">Best Category</p>
            <p className="text-2xl font-bold text-purple-600">Healthcare</p>
            <p className="text-xs text-gray-600">Rank 42/100</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PeerComparison;